package Libro;

import java.util.ArrayList;
//Lauren 
public class Main {

	public static void main (String[] args) {
		int id;
		
		CrearLibro libro1 =new CrearLibro("Aquitania","Eva", 2020, "Urturi",300);//Se crea el libro
		CrearLibro.guardarLibro(libro1);//Se guarda el libro
		
		
		CrearLibro libro2 =new CrearLibro("Examenes", "Juanan",2020,"Datos",10 );
		CrearLibro.guardarLibro(libro2);
	
		
		CrearLibro libro3 =new CrearLibro();
		CrearLibro.guardarLibro(libro3);
		
		
		CrearLibro libro4 =new CrearLibro("Muchos ceros","Juanan y Roberto", 2020, "Xuquer",200 );
		CrearLibro.guardarLibro(libro4);
		
		
		CrearLibro libro5 =new CrearLibro("Recuperaciones, ah no que no hay","Juanan y Roberto", 2020, "Xuquer",500 );
		CrearLibro.guardarLibro(libro5);
		

	
		id=CrearLibro.identificacion-1;//Asi diras i esto? Pues al fer el for, si recupere directament el CrearLibro.identificacion me diu que el valor es mes gran que la informacio que se recupera,
										//nose per que pero el valor de CrearLibro.identificacion cuan aplega asi se incrementa en 1 aixina que li reste 1 asi i arreglat XDDDDDD 
		
		ArrayList<CrearLibro> Libro=new ArrayList<CrearLibro>();//Cree el arraylist denominat Libro
		
		Libro=CrearLibro.recuperarLosLibros();//Guarde en libro la informacio que recupera el for de CrearLibro
		for(int i=0; i <=id; i++) {
			
			System.out.println(Libro.get(i).toString());//Mostre els datos de tots els llibres
	
		}
		

	}
}
