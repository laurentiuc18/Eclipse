package Libro;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;



public class CrearLibro implements Serializable {
//Creacion variable que pide el ejercicio
	
	static int identificacion;//statica porque me lo pide el sr.Java
	String titulo;
	String autor;
	int anyoPublicacion;
	String editor;
	int numeroPaginas;
	//Constructor de libros con parametros
	public CrearLibro(String titulo,String autor,int anyoPublicacion,String editor,int numeroPaginas){
		
		this.titulo=titulo;
		this.autor=autor;
		this.anyoPublicacion=anyoPublicacion;
		this.editor=editor;
		this.numeroPaginas=numeroPaginas;
		identificacion++;
	}
	//Constructor copia +identificacion porque si no , no suma
	public CrearLibro() {
		identificacion++;
	}
	
	//Que se muestre en String la informacion por que sino sale asi: Libro.CrearLibro@6debcae2
	public String toString() {
		String cosas="";
		
		cosas=cosas+"titulo: "+titulo+"\n";
		cosas=cosas+"Autor: "+autor+"\n";
		cosas=cosas+"A�o de publicacion: "+anyoPublicacion+"\n";
		cosas=cosas+"Editor: "+editor+"\n";
		cosas=cosas+"Numero de paginas: "+numeroPaginas+"\n\n";

		
		
		return cosas;
		
	}
	//Pues el cerrar que he copiado de personas XD
	public static void intentarCerrar(Closeable aCerrar) {
		try {
			if (aCerrar != null) {
				aCerrar.close();
			}
		} catch (IOException ex) {
			ex.printStackTrace(System.err);
		}
	}
	//copiat de Persones pero asi se crea y se guarda el llibre
	public static int guardarLibro(CrearLibro libro){
		
		ObjectOutputStream out=null;
		
		try {
			out = new ObjectOutputStream(new FileOutputStream("libro"+identificacion+".dat"));
			out.writeObject(libro);
		} catch (IOException e) {			
			e.printStackTrace();
		}finally{
			intentarCerrar(out);
		}
		return 0;
	}
	//Se recupera la informacio del llibre
	public static CrearLibro recuperarLibro(String identificador) {
		CrearLibro libro;
        ObjectInputStream in=null;
        try {
            in = new ObjectInputStream(new FileInputStream(identificador));
            libro = (CrearLibro) in.readObject(); 
            return libro;
        } catch (ClassNotFoundException ex) {
            System.err.println("Error de fichero");
        } catch (IOException ex) {
        	System.err.println("Error IO");
        }finally{
            intentarCerrar(in);
        }
        return null;
	}
	//Se recupera la informacio de tots els llibres creats
	static ArrayList<CrearLibro> recuperarLosLibros() {
		ArrayList <CrearLibro> libros = new ArrayList<CrearLibro>();
		
		for(int i=1; i <= identificacion; i++) {
			
			libros.add(recuperarLibro("libro"+ i+".dat"));
	
		}
		
		
		return libros;
		
		
		
	}
	
}
