package Paquete;

import java.rmi.NoSuchObjectException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class JuegoSudoku {
	
	static int valor;
	static int filas;
	static int columnas;
	static int nivel;
	
	static ArrayList<String> posicionesGuardadas = new ArrayList<String>();
	
	
	
	
	
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		int sudoku[][]= {	{0,3,4, 6,7,8, 9,1,2},//Llenar con 5
							{6,7,2, 1,9,0, 3,4,8},
							{1,9,8, 3,4,2, 0,6,7},
							
							{8,5,9, 7,6,1, 4,2,3},
							{8,2,6, 8,5,3, 7,2,1},
							{7,1,3, 9,2,4, 8,5,6},
							
							{9,6,1, 5,3,7, 2,8,4},
							{2,8,7, 4,1,9, 6,3,5},
							{3,4,5, 2,8,6, 1,7,9}};

		
		
	int sudoku2[][]= {	{0,0,0, 0,6,7, 0,0,9},
						{0,5,0, 0,0,2, 0,0,0},
						{6,0,7, 3,0,8, 0,2,0},
						
						{2,0,0, 0,0,6, 0,7,0},
						{0,0,0, 0,0,0, 0,0,0},
						{3,0,5, 0,9,0, 4,0,0},
						
						{0,3,0, 0,7,0, 0,0,0},
						{0,0,0, 0,4,0, 0,0,0},
						{0,0,6, 0,0,0, 0,8,0}};
		
				
		
		
		
		
		System.out.println("Que nivel desea? Lvl 1 o Lvl 2");
		nivel= sc.nextInt();
		
		do{
			if(nivel==2) {
				sudoku= sudoku2;
				
			}
			guardarPosiciones(sudoku);

		while (!FinalJuego(sudoku)) {

		
			crearSudoku(sudoku);
			
			
			System.out.println("ingrese Fila");
			filas = sc.nextInt();
			filas--;
			System.out.println("ingrese Columna");

			
			
			columnas = sc.nextInt();
			columnas--;
			if(ComprobarNumero()) {
			System.out.println("ingrese numero que quiera ingresar");
			valor = sc.nextInt();						
			
			
			IngresarDato(sudoku);
			}else {System.out.println("Filas/Columnas incorrectas");}

		}
		
		System.out.println("Has finalizado el juego");
		if(nivel==2) {
			nivel=0;
			System.out.println("Gracias Por Jugar");
		}else {nivel++;
		
		
		System.out.println("++++++++++++++++++++++++++");
		System.out.println("Pasando Al siguiente Nivel");
		System.out.println("++++++++++++++++++++++++++");
		}
		
		}while(nivel!=0);
		

			
	}
	
	
	//Dibujar Sudoku
	public static void crearSudoku(int sudoku[][]) {
		
		int contador=1;
		
		System.out.println("\n                        Nivel "+nivel);
		System.out.println("\n ┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┐");
		for (int i = 0; i < sudoku.length; i++) {
			
			System.out.print(contador);
			contador++;
			for (int j = 0; j < sudoku[0].length; j++) {
				
				
				if (sudoku[i][j] == 0) {
					System.out.printf("│%3s  ", " ");
				}
				else {					
					
						System.out.printf("│%3s  ", sudoku[i][j]);				
				}				
			}

			if (i != sudoku.length-1) {
				
				
				
				System.out.println("│\n ├─────┼─────┼─────┼─────┼─────┼─────┼─────┼─────┼─────┤");	
				
			}			
		}	

		System.out.println("│\n └─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┘");		
		System.out.println("    1     2     3     4     5     6     7     8     9 ");
		
	}

	//Guardar Casillas Vacias
	public static void guardarPosiciones(int sudoku[][]) {

		for (int i = 0; i < sudoku.length; i++) {

			for (int j = 0; j < sudoku.length; j++) {

				if (sudoku[i][j] == 0) {
					posicionesGuardadas.add(i + "" + j);

				}

			}

		}

	}

	//Compruebo si se puede ingresar el dato o no 
	public static void IngresarDato(int sudoku[][]) {
		String posicion = filas + "" + columnas;
		
		
		if(posicionesGuardadas.contains(posicion)){
		
		if(ComprobarFila(sudoku)) {System.out.println("Numero ya existe en la Fila");
		
		}else if(ComprobarColumna(sudoku)) {System.out.println("Numero ya existe en la Columna");
		
		
		}else if (ComprobarSector(sudoku)) {System.out.println("Numero ya existe en el Sector");
		
		}else {sudoku[filas][columnas] = valor; System.out.println("Numero ingresado");}
		
		
		}	else {System.out.println("Este numero no puede ser cambiado");}
		
		
		
	}
//Commpruebo si el numero esta en el rango requerido
	public static boolean ComprobarNumero() {
		boolean comprobar=false;
		
		if(filas>=0 && filas <=8) {
			if(columnas>=0 && columnas <=8) {
				comprobar=true;
		}else {comprobar=false;}
		
		}else {comprobar=false;}
		return comprobar;
		
		
	}

	//Compruebo si el numero existe en la fila
	public static boolean ComprobarFila(int sudoku[][]) {
		boolean comprobar= false;
		for (int j = 0; j < sudoku.length; j++) {

			if (sudoku[filas][j] == valor) {
				comprobar = true;
				break;
			} else {
				comprobar = false;
			}

		}
		return comprobar;

	}

	//Compruebo si el numero existe en la Columna
	public static boolean ComprobarColumna(int sudoku[][]) {
		boolean comprueba= false;
		for (int j = 0; j < sudoku.length; j++) {

			if (sudoku[j][columnas] == valor) {
				comprueba = true;
				break;
			} else {
				comprueba = false;
			}
		}
		return comprueba;

	}
	//Compruebo si el numero existe en el sector 3x3
	public static boolean ComprobarSector(int sudoku[][]) {
		boolean comprueba=false; 
		int numeroj = 0;
		int numeroi = 0;
		int numeroContadorj = 0;
		int numeroContadori = 0;
		if (filas <= 2) {
			numeroj = 0;

			numeroContadorj = 3;
		}
		if (filas >= 3 && filas <= 5) {
			numeroj = 3;
			numeroContadorj = 6;
		}
		if (filas >= 6 && filas <= 8) {
			numeroj = 6;
			numeroContadorj = 9;
		}

		if (columnas <= 2) {
			numeroi = 0;
			numeroContadori = 3;
		}
		if (columnas >= 3 && filas <= 5) {
			numeroi = 3;
			numeroContadori = 6;
		}
		if (columnas >= 6 && filas <= 8) {
			numeroi = 6;
			numeroContadori = 9;
		}

		for (int j = numeroj; j < numeroContadorj; j++) {
			boolean si = false;
			for (int i = numeroi; i < numeroContadori; i++) {
			
				if (sudoku[j][i] == valor) {
					comprueba = true;
					si = true;
					break;
					
				} else {
					comprueba = false;
				}
			}
			if (si) {
				break;
			}
			System.out.println();
		}
		return comprueba;

	}

	//Comprueba si el juego ha llegado a su final
	public static boolean FinalJuego(int sudoku[][]) {

		boolean comprobarFinal = true;
		for (int i = 0; i < sudoku.length; i++) {

			for (int j = 0; j < sudoku.length; j++) {

				if (sudoku[i][j] == 0) {

					comprobarFinal = false;
				}

			}

		}

		return comprobarFinal;
	}
}
