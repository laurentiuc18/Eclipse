package modelo;

import controlador.PongController;
import javafx.animation.AnimationTimer;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;

public class BolaAnimation extends AnimationTimer {

	private PongController pc;
	public static Circle bola;
	
	private int velocidadX_INI;
	private int velocidadX;
	private int velocidadY;
	private int velox;
	private int velocidad;
	private double ballCenterX;
	private double ballCenterY;	
	
	public BolaAnimation(PongController pc, Circle c, int vx, int vy,int velox,int velocidad) {
	
		this.pc   = pc;
		BolaAnimation.bola = c;
		this.velocidadX = vx;
		this.velocidadY = vy;
		this.velox=velox;
		this.velocidad=velocidad;
		this.velocidadX_INI = vx;
	}
	
	@Override
	public void handle(long arg0) {

		

		if(bola.isVisible()) {
			velocidad=velox;	
			if(velocidadX==0) {
				velocidadX=velox;
				velocidadY=velocidadX/2;
			}
			bola.setCenterX(ballCenterX);
			bola.setCenterY(ballCenterY);
			ballCenterX += velocidadX;
			ballCenterY += velocidadY;
		/*
			}else {
				ballCenterX=pc.gallina.getLayoutX();
				ballCenterY=pc.gallina.getLayoutY();
			}
		Shape bola2ColisionBola3 = Shape.intersect(pc.izquierda, bola);
		 boolean bola2Izquierda = bola2ColisionBola3.getBoundsInLocal().isEmpty();

		Shape bola2ColisionBola4 = Shape.intersect(pc.derecha, bola);
		boolean bola2Derecha = bola2ColisionBola4 .getBoundsInLocal().isEmpty();
		Shape bola2ColisionBola5 = Shape.intersect(pc.arriba, bola);
		 boolean bola2Arriba = bola2ColisionBola5 .getBoundsInLocal().isEmpty();

		Shape bola2ColisionBola6 = Shape.intersect(pc.abajo, bola);
		boolean bola2Abajo = bola2ColisionBola6 .getBoundsInLocal().isEmpty();
		Shape bola2ColisionBola7 = Shape.intersect(pc.bola, bola);
		boolean bola2bola = bola2ColisionBola7 .getBoundsInLocal().isEmpty();
		
		if(pc.segundos>=3) {
			pc.segundos=3;
		}
		 String sec = Integer.toString(pc.segundos);
		pc.tiempo.setText(sec);
		if(bola.isVisible()) {
			if(pc.segundos>=2) {
			if (!bola2Arriba || !bola2Abajo) {//298=BordeAbjo 248=BordeArriba
				
				
				velocidadX = velocidadX *(-1);

			}
			
			if (!bola2Izquierda || !bola2Derecha) {//380=BordeDerecha  -346=BordeIzquierda
				
				
				
				velocidadX = velocidadX *(-1);
				
				}
			if (!bola2bola) {
				
				
				
				velocidadX = velocidadX * (-1);
				
				}
			}
			if(pc.segundos>=3) {
			if(!bola2Derecha) {
				
				pc.ContRebotesPelota2=0;
				ballCenterX=0;
				ballCenterY=0;
				bola.setCenterX(ballCenterX);
				bola.setCenterY(ballCenterY);
				
				bola.setVisible(false);
				//bola2.setDisable(true);
				pc.puntos1=pc.puntos1+0.1;
				pc.puntuacionJugador1.setProgress(pc.puntos1);
			}
			
			
			if(!bola2Izquierda ) {
			
				pc.ContRebotesPelota2=0;
				ballCenterX=0;
				ballCenterY=0;
				bola.setCenterX(ballCenterX);
				bola.setCenterY(ballCenterY);
				bola.setVisible(false);
				//bola2.setDisable(true);
				pc.puntos2=pc.puntos2+0.1;
				pc.puntuacionJugador2.setProgress(pc.puntos2);
			}
			}
	}

		//Detectar colisión Jugador 1
		Shape shapeCollision1  = Shape.intersect(pc.player1, bola);
		boolean colisionVacia1 = shapeCollision1.getBoundsInLocal().isEmpty();

		if (!colisionVacia1) {
			velocidadX = +velocidad;
		}

		//Detectar colisión Jugador 2
		Shape shapeCollision2  = Shape.intersect(pc.player2, bola);
		boolean colisionVacia2 = shapeCollision2.getBoundsInLocal().isEmpty();

		//Rebotar
		if (!colisionVacia2) {
			velocidadX = +velocidad;
			*/
		}
		

		
	}
	
}