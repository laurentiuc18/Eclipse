package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class archivo1 {
	
	public static BufferedReader abrirReader (String file) throws FileNotFoundException {
		FileReader fileReader = new FileReader(file);
		BufferedReader buffRead = new BufferedReader(fileReader);
		return buffRead;
	}

	public static void cerrarReader (BufferedReader buffRead) throws IOException {
		buffRead.close();
	}
	
	public static BufferedWriter openWriter (String fichero1) throws IOException {
		BufferedWriter buffRead = new BufferedWriter(new FileWriter("Configuracion.txt"));
		return buffRead;
	}

	public static void cerrarWriter (BufferedWriter buffRead) throws IOException {
		buffRead.close();
	}
}
