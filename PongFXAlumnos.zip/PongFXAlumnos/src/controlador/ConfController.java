package controlador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.stage.Stage;
import modelo.archivo1;

public class ConfController {

	@FXML private CheckBox player1;
	@FXML private CheckBox player2;
	@FXML private Slider velocidad;
	@FXML private Button Guardar;
	@FXML private Button Cancelar;
	@FXML
	void initialize() throws IOException {
		Cargar("Configuracion.txt");
	}
	
	void Cargar(String archivo) throws IOException {
		BufferedReader buffRead = archivo1.abrirReader(archivo);
		String linea = buffRead.readLine();
		
		if (linea.contains("true")) {
			player1.setSelected(true);
		}else player1.setSelected(false);
		linea = buffRead.readLine();
		if (linea.contains("true")) {
			player2.setSelected(true);
		}else player2.setSelected(false);
		linea = buffRead.readLine();
		velocidad.setValue(Integer.parseInt(linea));
		
		archivo1.cerrarReader(buffRead);

	}

	@FXML
	void cancelar(ActionEvent event) throws IOException {
		Stage stage = (Stage) Cancelar.getScene().getWindow();
		stage.close();
	}


	@FXML
	void guardar(ActionEvent event) throws IOException {
		BufferedWriter buffWrit = archivo1.openWriter("Configuracion.txt");
		
		if (player1.isSelected()) {
			buffWrit.write("true");
		} else buffWrit.write("false");
		buffWrit.newLine();
		if (player2.isSelected()) {
			buffWrit.write("true");
		} else buffWrit.write("false");
		buffWrit.newLine();
		buffWrit.write("" + (int) velocidad.getValue());
		
		archivo1.cerrarWriter(buffWrit);
		Stage stage = (Stage) Guardar.getScene().getWindow();
		stage.close();
	}
}
