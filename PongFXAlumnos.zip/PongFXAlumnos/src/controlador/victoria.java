package controlador;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Modality;
import javafx.stage.Stage;



public class victoria {
	
	@FXML public Label Lvictoria;
	

	   
	   private void abrirVictoria()  {
		   
		   
		   
	    	 try{

	    	 FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/vista/Victoria.fxml"));
	    	Parent root = (Parent) fxmlLoader.load();
	    	 Stage stage = new Stage();
	    	stage.setTitle("Victoria");
	    	stage.setResizable(false);
	    	stage.initModality(Modality.APPLICATION_MODAL);
	    	stage.setScene(new Scene(root));
	    	//Mostrar el Stage (ventana)
	   
	    	stage.show();
	    	
	    
	    	 }
	    	catch (Exception e){
	    	e.printStackTrace();
	    	}
	    }
	   
	

	   public  void abrir() {
		   
		  abrirVictoria();
		 // Lvictoria.setText("hola");
	   }
	
}
