package controlador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.scene.Parent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import modelo.archivo1;


public class ToolBarController {

	    @FXML
	    private void abrirConfiguracion() {

	    	 try{

	    	 FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/vista/configuration.fxml"));
	    	Parent root = (Parent) fxmlLoader.load();

	    	 Stage stage = new Stage();
	    	stage.setTitle("Configuracion");
	    	stage.setResizable(false);
	    	stage.initModality(Modality.APPLICATION_MODAL);
	    	stage.setScene(new Scene(root));
	    	//Mostrar el Stage (ventana)
	    	stage.show();

	    	 }
	    	catch (Exception e){
	    	e.printStackTrace();
	    	}
	    }
	
}