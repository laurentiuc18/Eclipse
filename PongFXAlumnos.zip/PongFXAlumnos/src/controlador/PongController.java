package controlador;
import java.awt.font.ImageGraphicAttribute;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import modelo.archivo1;

public class PongController {

	@FXML private GridPane paneToolBar;
	@FXML private AnchorPane paneMenuNavigationDrawer;
	@FXML private AnchorPane paneMenuToolbar;
	@FXML private Pane paneEffectDisable;
	 private AnimationTimer animationBall;
	 
	 @FXML private Label tiempo;
	 @FXML private Line izquierda;
	 @FXML private Line derecha;
	 @FXML private Line arriba;
	 @FXML private Line abajo;
	 @FXML private Button info;
	 @FXML private Circle prueba;
	 @FXML private Circle bola;
	 @FXML private Circle bola2;
	 @FXML private Rectangle player1, player2;
	 @FXML public ProgressBar puntuacionJugador1;
	 @FXML public ProgressBar puntuacionJugador2;
	 @FXML private ImageView gallina;
	 private int posX=0;
	 private int posY=0;
	 private int velociX;
	 private int velociY= velociX/2;
	 private int velociXG= 3;
	 private int velociYG= 0;
	 private int velox;
	 int ContRebotesPelota1=0;
	 //bola2
	 private int velocidad;
	 private double bola2PosX;
	 private double bola2PosY;
	 boolean imagen=false;
	
	 int  bola2VelociX;
	 int  bola2VelociY;
	 int ContRebotesPelota2=0;
	 //Jugadores
	 private int posY_jug1= 0;
	 private int posY_jug2= 0;
	 private int vel_jug1= 0;
	 private int vel_jug2= 0;
	 private double puntos1=0;
	 private double puntos2=0;
	 private boolean gallinaActiva=true;
	 int segundos=0;
	 Timer timer = new Timer();
	 Timer timer2 = new Timer();
	
	 //Animcaion Jugadores
	 private AnimationTimer animationPlayers = new AnimationTimer() {
		 
		 @Override
		 public void handle(long now) {
			
		 posY_jug1 += vel_jug1;
		 posY_jug2 += vel_jug2;
		
		 player1.setY(posY_jug1);
		 player2.setY(posY_jug2);
		 }
		 };
		 
		

	@FXML
	void initialize() {
		
		AspectoPelota();
		AspectoPelota2();
		  
		Image pala = new Image("vista/img/pala1.png",false); 
		Image pala2 = new Image("vista/img/pala2.png",false); 

		player1.setFill(new ImagePattern(pala2));
		player2.setFill(new ImagePattern(pala));

		animationBall =new AnimationTimer() {
			
			@Override 
			public void handle(long arg0) {
				
				//Bola1
				posX =posX +velociX;
				posY =posY +velociY;
				bola.setCenterX(posX);
				bola.setCenterY(posY);
				
				//Gallina
				gallina.setLayoutX(gallina.getLayoutX() +velociXG);
				gallina.setLayoutY(gallina.getLayoutY() +velociYG);
				
				//Bola2
				if(bola2.isVisible()) {
				velocidad=velox;	
				if(bola2VelociX==0) {
					bola2VelociX=velox;
					bola2VelociY=bola2VelociX/2;
				}
				bola2PosX =bola2PosX +bola2VelociX;
				bola2PosY =bola2PosY +bola2VelociY;
				bola2.setCenterX(bola2PosX);
				bola2.setCenterY(bola2PosY);
				}else {
					bola2PosX=gallina.getLayoutX();
					bola2PosY=gallina.getLayoutY();
				}
				
			
				//Colisiones
				
				//bola1 y barra
				Shape shapeCollision1 = Shape.intersect(player1, bola);
				 boolean colisionVacia1 = shapeCollision1.getBoundsInLocal().isEmpty();

				Shape shapeCollision2 = Shape.intersect(player2, bola);
				boolean colisionVacia2 = shapeCollision2.getBoundsInLocal().isEmpty();
				
				if (!colisionVacia1 ) {//choque contra barra jugador
					ContRebotesPelota1++;
					velociX = +velox;
					imagen=true;
					

				}
				
				if(!colisionVacia2 ) {//choque contra barra jugador
					ContRebotesPelota1++;
					velociX = -velox;
					imagen=true;
				}
				
			
				//Bola1
				Shape colisionBola3 = Shape.intersect(izquierda, bola);
				 boolean bolaIzquierda = colisionBola3.getBoundsInLocal().isEmpty();

				Shape colisionBola4 = Shape.intersect(derecha, bola);
				boolean bolaDerecha = colisionBola4.getBoundsInLocal().isEmpty();
				Shape colisionBola5 = Shape.intersect(arriba, bola);
				 boolean bolaArriba = colisionBola5.getBoundsInLocal().isEmpty();

				Shape colisionBola6 = Shape.intersect(abajo, bola);
				boolean bolaAbajo = colisionBola6.getBoundsInLocal().isEmpty();
				
				if (!bolaArriba || !bolaAbajo) {//298=BordeAbjo 248=BordeArriba
					
					
					velociY = velociY * (-1);
				}
				
				/*if (!bolaIzquierda || !bolaDerecha) {//380=BordeDerecha  -346=BordeIzquierda
					
					
					
					velociX = velociX * (-1);
					
				}*/
			
				if(!bolaDerecha) {
					imagen=true;
					ContRebotesPelota1=0;
					posX=0;
					posY=0;
					bola.setCenterX(posX);
					bola.setCenterY(posY);
					puntos1=puntos1+0.1;
					puntuacionJugador1.setProgress(puntos1);
				}
				
				
				if(!bolaIzquierda ) {
					imagen=true;
					ContRebotesPelota1=0;
					posX=0;
					posY=0;
					bola.setCenterX(posX);
					bola.setCenterY(posY);
					puntos2=puntos2+0.1;
					puntuacionJugador2.setProgress(puntos2);
				}
				
				if(imagen) {
					AspectoPelota();
				}
				//Bola 2 y barra
				Shape bola2ColisionJugador = Shape.intersect(player1, bola2);
				 boolean bola2Vacia1 = bola2ColisionJugador.getBoundsInLocal().isEmpty();

				Shape bola2ColisionJugador2 = Shape.intersect(player2, bola2);
				boolean bola2Vacia2 = bola2ColisionJugador2.getBoundsInLocal().isEmpty();
				
				if (!bola2Vacia1 ) {//choque contra barra jugador
					ContRebotesPelota2++;
					bola2VelociX = +velocidad;
			
				

					}
					
					if(!bola2Vacia2 ) {//choque contra barra jugador
						ContRebotesPelota2++;
						bola2VelociX = -velocidad;
					
					
					}
				//Bola2
				Shape bola2ColisionBola3 = Shape.intersect(izquierda, bola2);
				 boolean bola2Izquierda = bola2ColisionBola3.getBoundsInLocal().isEmpty();

				Shape bola2ColisionBola4 = Shape.intersect(derecha, bola2);
				boolean bola2Derecha = bola2ColisionBola4 .getBoundsInLocal().isEmpty();
				Shape bola2ColisionBola5 = Shape.intersect(arriba, bola2);
				 boolean bola2Arriba = bola2ColisionBola5 .getBoundsInLocal().isEmpty();

				Shape bola2ColisionBola6 = Shape.intersect(abajo, bola2);
				boolean bola2Abajo = bola2ColisionBola6 .getBoundsInLocal().isEmpty();
				Shape bola2ColisionBola7 = Shape.intersect(bola, bola2);
				boolean bola2bola = bola2ColisionBola7 .getBoundsInLocal().isEmpty();
				
				if(segundos>=3) {
					segundos=3;
				}
				 String sec = Integer.toString(segundos);
				tiempo.setText(sec);
				if(bola2.isVisible()) {
					if(segundos>=2) {
					if (!bola2Arriba || !bola2Abajo) {//298=BordeAbjo 248=BordeArriba
						
						
						bola2VelociY = bola2VelociY * (-1);
					}
					
					if (!bola2Izquierda || !bola2Derecha) {//380=BordeDerecha  -346=BordeIzquierda
						
						
						
						bola2VelociX = bola2VelociX * (-1);
						
						}
					if (!bola2bola) {
						
						
						
						bola2VelociX = bola2VelociX * (-1);
						
						}
					}
					if(segundos>=3) {
					if(!bola2Derecha) {
						
						ContRebotesPelota2=0;
						bola2PosX=0;
						bola2PosY=0;
						bola2.setCenterX(bola2PosX);
						bola2.setCenterY(bola2PosX);
						
						bola2.setVisible(false);
						//bola2.setDisable(true);
						puntos1=puntos1+0.1;
						puntuacionJugador1.setProgress(puntos1);
					}
					
					
					if(!bola2Izquierda ) {
					
						ContRebotesPelota2=0;
						bola2PosX=0;
						bola2PosY=0;
						bola2.setCenterX(bola2PosX);
						bola2.setCenterY(bola2PosX);
						bola2.setVisible(false);
						//bola2.setDisable(true);
						puntos2=puntos2+0.1;
						puntuacionJugador2.setProgress(puntos2);
					}
					}
			}
				
			
				//Jugadores
			
			
				

				if(player1.getY()<=-182) {
					posY_jug1=-181;
				}
				
				if(player1.getY()>=270) {
								
					posY_jug1=269;	
							}
				
				if(player2.getY()<=-182) {
					posY_jug2=-181;
				}
				
				if(player2.getY()>=270) {
								
					posY_jug2=269;	
							}

				// Gallina

				if (gallinaActiva) {
					if (gallina.getLayoutX() >= 680) {
						velociXG = 0;
						velociYG = -1;
						gallina.setLayoutX(gallina.getLayoutX() + velociXG);
						gallina.setLayoutY(gallina.getLayoutY() + velociYG);

						gallina.setRotate(-90);

					}
					if (gallina.getLayoutY() <= 3 && gallina.getLayoutX() >= 680) {
						velociXG = -3;
						velociYG = 0;
						gallina.setLayoutX(gallina.getLayoutX() + velociXG);
						gallina.setLayoutY(gallina.getLayoutY() + velociYG);

						gallina.setRotate(180);

					}
					if (gallina.getLayoutX() <= 17) {

						velociXG = 0;
						velociYG = 3;
						gallina.setLayoutX(gallina.getLayoutX() + velociXG);
						gallina.setLayoutY(gallina.getLayoutY() + velociYG);
						gallina.setRotate(90);

						gallinaActiva = false;
					}

				}

				if (!gallinaActiva) {
					if (gallina.getLayoutY() >= 477) {
						velociXG = 3;
						velociYG = 0;
						gallina.setLayoutX(gallina.getLayoutX() + velociXG);
						gallina.setLayoutY(gallina.getLayoutY() + velociYG);
						gallina.setRotate(0);

						gallinaActiva = true;
					}
				}

			victoria();
				
			}
		};
		
		//Cargar los 2 menús
		try {	
			
			try {
				cargar("Configuracion.txt");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			VBox menuNavigationDrawer = FXMLLoader.load(getClass().getResource("/vista/MenuNavigationDrawer.fxml"));
			paneMenuNavigationDrawer.getChildren().add(menuNavigationDrawer);

			VBox menuToolbar = FXMLLoader.load(getClass().getResource("/vista/MenuToolbar.fxml"));
			paneMenuToolbar.getChildren().add(menuToolbar);
			
			
			

		} catch (IOException ex) {
			Logger.getLogger(PongController.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		//Al iniciar la aplicación, no se muestran los paneles
		paneMenuNavigationDrawer.setVisible(false);
		paneMenuToolbar.setVisible(false);
		paneEffectDisable.setVisible(false);  
		
	
	}	    
	
	
    
	//**************************************************************************
	// Acciones para los menús
	//**************************************************************************
	@FXML
	private void onMouseExitedPaneNavigationDrawer(MouseEvent event) {
		paneMenuNavigationDrawer.setVisible(false);
		paneEffectDisable.setVisible(false);
	}

	@FXML
	private void onMouseExitedPaneToolbarMenu(MouseEvent event) {
		paneMenuToolbar.setVisible(false);
		paneEffectDisable.setVisible(false);
	}

	@FXML
	private void onMouseClickedMenuNavigationDrawer(MouseEvent event) {
		paneMenuNavigationDrawer.setVisible(!paneMenuNavigationDrawer.isVisible());
		paneMenuToolbar.setVisible(false);
		paneEffectDisable.setVisible(true);
	}

	@FXML
	private void onMouseClickedMenuToolbar(MouseEvent event) {
		paneMenuToolbar.setVisible(!paneMenuToolbar.isVisible());
		paneMenuNavigationDrawer.setVisible(false);
		paneEffectDisable.setVisible(true);
	}
	
	//**************************************************************************
	// Otras funciones
	//**************************************************************************
	Image Huevo = new Image("vista/img/MiHuevo.png",false); 
	Image Roto1 = new Image("vista/img/HuevoRoto1.png",false);
	Image Roto2 = new Image("vista/img/HuevoRoto2.png",false);
	Image Roto3 = new Image("vista/img/HuevoRoto3.png",false);
	Image Pollo1 = new Image("vista/img/Pollo1.png",false); 
	Image Pollo2 = new Image("vista/img/Pollo2.png",false);
	private void AspectoPelota() {
		
		
		
		if(ContRebotesPelota1<=14) {
			
			bola.setFill(new ImagePattern(Huevo));
		}
		if(ContRebotesPelota1>15&&ContRebotesPelota1<=29) {
			bola.setFill(new ImagePattern(Roto1));
		}
		if(ContRebotesPelota1>30&&ContRebotesPelota1<=44) {
			bola.setFill(new ImagePattern(Roto2));
		}
		if(ContRebotesPelota1>=45&&ContRebotesPelota1<=59) {
			bola.setFill(new ImagePattern(Roto3));
		}
		if(ContRebotesPelota1>=60&&ContRebotesPelota1<=74) {
			bola.setFill(new ImagePattern(Pollo1));
		}
		if(ContRebotesPelota1>=75) {
			bola.setFill(new ImagePattern(Pollo2));
		}
		
		imagen=false;
	}
	
	
	private void AspectoPelota2() {
	
		if(ContRebotesPelota2<=14) {
			
			bola2.setFill(new ImagePattern(Huevo));
		}
		if(ContRebotesPelota2>15&&ContRebotesPelota2<=29) {
			bola2.setFill(new ImagePattern(Roto1));
		}
		if(ContRebotesPelota2>30&&ContRebotesPelota2<=44) {
			bola2.setFill(new ImagePattern(Roto2));
		}
		if(ContRebotesPelota2>=45&&ContRebotesPelota2<=59) {
			bola2.setFill(new ImagePattern(Roto3));
		}
		if(ContRebotesPelota2>=60&&ContRebotesPelota2<=74) {
			bola2.setFill(new ImagePattern(Pollo1));
		}
		if(ContRebotesPelota2>=75) {
			bola2.setFill(new ImagePattern(Pollo2));
		}
		
	}
	private void victoria() {
		if(puntuacionJugador1.getProgress()>=0.9) {
			
			animationBall.stop();
		 
				victoria vc =new victoria();
				
					vc.abrir();
					
		}
		if (puntuacionJugador2.getProgress()>=0.9) {
			
			animationBall.stop();
			 
			victoria2 vc2 =new victoria2();
		
				vc2.abrir();
		}
	}
	
	
	@FXML
	private void play(MouseEvent event) {
		bola2.setVisible(false);
		tiempoInmune();
		tiempo();
		jugar();
		
		
		try {
			animationPlayers.start();
			animationBall.start();
			if (velociX > 0) {
				cargar();
				velociY=velociX/2;
			} else {
				cargar();
				velociX = -velociX;
				velociY=velociX/2;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void jugar() {//Jugadores barras laterales
		Scene scene= player1.getScene();
		scene.setOnKeyPressed(e ->{
		if(e.getCode() == KeyCode.W){ vel_jug1 = -7; }
		if(e.getCode() == KeyCode.S){ vel_jug1 = +7; }
		if(e.getCode() == KeyCode.UP){ vel_jug2 = -7; }
		if(e.getCode() == KeyCode.DOWN){ vel_jug2 = +7; }
		});
		scene.setOnKeyReleased(e ->{
		if ( (e.getCode() == KeyCode.W) || (e.getCode() ==
		KeyCode.S) ){
		vel_jug1 = 0;
		}
		if ( (e.getCode() == KeyCode.UP) || (e.getCode() ==
		KeyCode.DOWN) ){
		vel_jug2 = 0;
		}
		});
	}
	
	
	private void tiempo() {//Aparicion bola
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						//Hacer cosas
					 
						if(!bola2.isVisible()) {
							
							bola2.setVisible(true);
							bola2VelociY=bola2VelociX/2;
						}
					}
				});
			}
		}, 10000, 5000); //1000 milisegundos = 1 segundo
	}
	
	private void tiempoInmune() {//Aparicion bola
		timer2.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						//Hacer cosas
					
					 if(!bola2.isVisible()) {
						 segundos=0;
						 AspectoPelota2();
					 }
						segundos++;
					}
				});
			}
		}, 10000, 1000); //1000 milisegundos = 1 segundo
	}
    @FXML
    void restart(MouseEvent event) {
    	
			
		animationBall.stop();
			
		
    	posX=0;
		posY=0;
		vel_jug1=0;
		vel_jug2=0;
		puntos1=0;
		puntos2=0;
		posY_jug1=0;
		posY_jug2=0;
		bola.setCenterX(posX);
		bola.setCenterY(posY);
		puntuacionJugador1.setProgress(puntos1);
		puntuacionJugador2.setProgress(puntos2);
		player1.setY(posY_jug1);
		player2.setY(posY_jug2);
		
		
    }
	
	@FXML
	private void stop(MouseEvent event) {
		
		
		try {
			animationPlayers.stop();
			animationBall.stop();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void cargar(String archivo) throws IOException {
		BufferedReader buffRead = archivo1.abrirReader(archivo);
		String linea = buffRead.readLine();
		linea = buffRead.readLine();
		linea = buffRead.readLine();
		velox=(Integer.parseInt(linea));
		velociX = (Integer.parseInt(linea));
		linea = buffRead.readLine();
		
		archivo1.cerrarReader(buffRead);
	}

	@FXML
	void cargar() {
		try {
			cargar("Configuracion.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
    @FXML
   private void info(MouseEvent event) {

    	info in =new info();
		
		in.abrir();
    }

}